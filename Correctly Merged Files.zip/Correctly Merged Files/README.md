# Kyle-Aaron-Morgan-GPA-Probation-App
How to open the web App: Go to the development branch and download the Web GPA Calculator folder. Then launch the GPAToAchieve.html.

How to install the Android app: Either go to https://github.com/huberkyle/Kyle-Aaron-Morgan-GPA-Probation-App/blob/Development/GPA%20Calculator.apk?raw=true or download the GPA Calculator.apk from the development branch on your Android device. Once downloaded open the file and hit the install button.

To test the app, go to the development branch and download the Web GPA Calculator folder. Then launch the selenium IDE in Firefox. From the Selenium IDE open up the test cases. The test cases will need to be updated to corresponding to the location of where the GPAToAchieve.html file is downloaded onto your computer.

To run tests:
    1. Open the GPA Application in FireFox. 
    2. Download the test file.
    3. From the FireFox Tools tab, select the Selenium plug-in. 
                Note: Selenium can be downloaded for free from the FireFox add-on page.
    4. In Selenium, select 'File' then open, then the test file.
    5. Click on the 'Play entire test suite' button to run all of the tests.
    6. To run a single test, select a test case from the panel from the left, then click on the         'Play current test case' button.
